import Footer from "../../components/shared/footer";
import Header from "../../components/shared/header";
import Teamsemua from "../../components/shared/team";

export default function Team() {
  return (
    <>
      <Header />
      <Teamsemua />
      <Footer />
    </>
  );
}
