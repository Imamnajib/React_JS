import Footer from "../../components/shared/footer";
import Header from "../../components/shared/header";
import Kontak from "../../components/shared/kontak";

export default function Contact() {
  return (
    <>
      <Header />
      <Kontak />
      <Footer />
    </>
  );
}
